<div style="color: red;">
    <?= esc($message) ?>
</div>