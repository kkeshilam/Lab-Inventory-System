<div style="color: green;">
    <?= esc($message) ?>
</div>