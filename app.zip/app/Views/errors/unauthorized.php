<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unauthorized</title>
</head>

<body>
    <h1>Unauthorized Access</h1>
    <p>You do not have permission to access this page.</p>
    <a href="/login">Go to Login</a>
</body>

</html>